-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2021 at 02:04 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sales_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_information`
--

CREATE TABLE `company_information` (
  `company_id` varchar(250) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company_information`
--

INSERT INTO `company_information` (`company_id`, `company_name`, `email`, `address`, `mobile`, `website`, `status`) VALUES
('1', 'Demo LTD', 'example@gmail.com', '4th Floor Mannan Plaza,Khilkhet,Dhaka-1229', '234234', 'httpss://www.bdtask.com/', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sls_customers`
--

CREATE TABLE `sls_customers` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat_number` varchar(255) DEFAULT NULL,
  `status` int(2) NOT NULL COMMENT '1=paid,2=credit',
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `create_by` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sls_customers`
--

INSERT INTO `sls_customers` (`id`, `name`, `company_name`, `phone`, `email`, `address`, `city`, `state`, `zip`, `country`, `vat_number`, `status`, `create_date`, `create_by`) VALUES
(1, 'Walking Customer', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2020-03-03 01:23:10', NULL),
(2, 'Test', NULL, '01558930222', 'admin34@example.com', 'test', 'test', '', '', '', NULL, 1, '2021-05-24 12:20:15', '500636'),
(3, 'Test', 'test', '01558930222', 'admin@example.com', 'test', 'test', 'Test', '1211', 'BDESH', '1122', 1, '2021-05-24 12:24:47', '2'),
(4, 'Test', 'test', '1232', 'admin2@example.com', 'test', 'test', '', '', '', '', 1, '2021-05-24 15:12:45', '2'),
(7, 'Test6', 'test6', '015589', 'admin6@example.com', 'test', 'test', '', '', '', '', 1, '2021-05-24 15:14:33', '2'),
(8, 'Test7', 'test7', '01767896', 'admin7@example.com', 'test', 'test', '', '', '', '', 1, '2021-05-24 15:15:16', '2'),
(9, 'aisoft', 'Owner', '015589', 'aisoft@example.com', 'test', 'test', 'Test', '1211', 'BDESH', '1122', 1, '2021-05-25 06:10:15', '2');

-- --------------------------------------------------------

--
-- Table structure for table `sls_suppliers`
--

CREATE TABLE `sls_suppliers` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat_number` varchar(255) DEFAULT NULL,
  `status` int(2) NOT NULL COMMENT '1=paid,2=credit',
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `create_by` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sls_suppliers`
--

INSERT INTO `sls_suppliers` (`id`, `name`, `company_name`, `phone`, `email`, `address`, `city`, `state`, `zip`, `country`, `vat_number`, `status`, `create_date`, `create_by`) VALUES
(3, 'Test', 'test', '01558930222', 'admin@example.com', 'test', 'test', 'Test', '1211', 'BDESH', '1122', 1, '2021-05-24 12:24:47', '2'),
(4, 'Test', 'test', '1232', 'admin2@example.com', 'test', 'test', '', '', '', '', 1, '2021-05-24 15:12:45', '2'),
(7, 'Test6', 'test6', '015589', 'admin6@example.com', 'test', 'test', '', '', '', '', 1, '2021-05-24 15:14:33', '2'),
(8, 'Test7', 'test7', '01767896', 'admin7@example.com', 'test', 'test', '', '', '', '', 1, '2021-05-24 15:15:16', '2'),
(9, 'aisoft', 'Owner', '015589', 'aisoft@example.com', 'test', 'test', 'Test', '1211', 'BDESH', '1122', 1, '2021-05-25 06:10:15', '2'),
(10, 'Test Supplier', 'testsup', '01558933', 'admintest@example.com', 'testsup', 'test', 'Testsup', '121133', 'BDESH', '112233', 1, '2021-05-25 08:36:38', '2');

-- --------------------------------------------------------

--
-- Table structure for table `sls_users`
--

CREATE TABLE `sls_users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(15) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_type` int(2) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `company_name` varchar(250) DEFAULT NULL,
  `logo` varchar(250) DEFAULT NULL,
  `security_code` varchar(255) DEFAULT NULL,
  `status` int(2) NOT NULL,
  `is_ban` tinyint(2) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sls_users`
--

INSERT INTO `sls_users` (`id`, `user_id`, `username`, `password`, `phone`, `email`, `user_type`, `last_name`, `first_name`, `company_name`, `logo`, `security_code`, `status`, `is_ban`) VALUES
(1, '2', 'admin@example.com', '41d99b369894eb1ec3f461135132d8bb', '', 'admin@example.com	', 1, '', '', NULL, NULL, NULL, 1, 0),
(2, '500636', 'aisoft@example.com', '41d99b369894eb1ec3f461135132d8bb', '01558930222', 'aisoft@example.com', 1, '', '', NULL, NULL, NULL, 1, 0),
(5, '944721', 'admin2@example.com', '41d99b369894eb1ec3f461135132d8bb', '+355672122345', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(6, '723691', 'admin3@example.com', '41d99b369894eb1ec3f461135132d8bb', '01558930222', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(16, '849900', 'admin55@example.com', '41d99b369894eb1ec3f461135132d8bb', '+8801558934345', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(8, '661309', 'admin5@example.com', '41d99b369894eb1ec3f461135132d8bb', '01558930222', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(9, '228799', 'admin6@example.com', '41d99b369894eb1ec3f461135132d8bb', '01558930222', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(10, '548261', 'admin@example.com', '41d99b369894eb1ec3f461135132d8bb', '01558930222', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(17, '476538', 'owner@tecdiary.com', '82c1ab9f315f15ff53d5bba77c9a1884', '+355672133456', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(12, '125832', 'admin9@example.com', '41d99b369894eb1ec3f461135132d8bb', '01558930222', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(13, '493344', 'admin@example.com', '41d99b369894eb1ec3f461135132d8bb', '01558930222', 'admin@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(14, '597571', 'admin12@example.com', '41d99b369894eb1ec3f461135132d8bb', '+1123124', 'admin12@example.com', 0, 'Aisoft', 'Aisoft', NULL, './assets/uploads/users/iguacu-falls-argentina-1_1621783704.jpg', NULL, 1, 0),
(15, '898001', 'ferdous1122@example.com', '41d99b369894eb1ec3f461135132d8bb', '01558930222', 'ferdous1122@example.com', 0, '', '', NULL, NULL, NULL, 1, 0),
(18, '284963', 'aisoft11@example.com', '41d99b369894eb1ec3f461135132d8bb', '+8801746457890', 'aisoft11@example.com', 0, 'Ltd', 'Aisoft', NULL, './admin/assets/img/user/2021-05-23/0c193f585f3b9fdc7ca3019df058a95f.jpg', NULL, 1, 0),
(19, '222789', 'admin13@example.com', 'a9f271f4c83b2268ca22fb7ef04727c2', '+11231244', 'admin13@example.com', 0, 'Salehin', 'Ferdous', NULL, './assets/uploads/users/46_49_1621840225.jpg', NULL, 1, 0),
(20, '88489', 'admin14@example.com', '5ebe9dd4ea7517bd2c30bc46985ef823', '+11231248', 'admin14@example.com', 0, 'Salehin', 'Ferdous', NULL, '', NULL, 1, 0),
(21, '804243', 'admin15@example.com', '41d99b369894eb1ec3f461135132d8bb', '+11234567', 'admin15@example.com', 0, 'Salehin', 'Ferdous', NULL, '', NULL, 1, 0),
(22, '413202', 'owner33@tecdiary.com', '82c1ab9f315f15ff53d5bba77c9a1884', '+1234224', 'owner33@tecdiary.com', 0, 'Aisoft', 'Aisoft', NULL, './admin/assets/img/user/2021-05-23/054610f930db49f1751a26ae75c4382c.jpg', NULL, 1, 0),
(23, '928400', 'ownersd@tecdiary.com', '82c1ab9f315f15ff53d5bba77c9a1884', '+112345', 'adminasd@example.com', 0, 'Salehin', 'Ferdous', NULL, 'E1P.jpg', NULL, 1, 0),
(24, '772860', 'owner423@tecdiary.com', '82c1ab9f315f15ff53d5bba77c9a1884', '+123424', 'admin432@example.com', 0, 'Salehin', 'Ferdous', NULL, NULL, NULL, 1, 0),
(25, '418517', 'owner3311@tecdiary.com', '82c1ab9f315f15ff53d5bba77c9a1884', '+11231414', 'admin3311@example.com', 0, 'Salehin', 'Ferdous', NULL, './assets/uploads/users/R4bc55f1d2861da6cf01465822d3a2d92_1621783935.jpg', NULL, 1, 0),
(26, '194695', 'ownervc@tecdiary.com', '82c1ab9f315f15ff53d5bba77c9a1884', '+1324234', 'admincv@example.com', 0, 'Salehin', 'Ferdous55', NULL, './assets/uploads/users/R4bc55f1d2861da6cf01465822d3a2d92_1621784098.jpg', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sls_web_setting`
--

CREATE TABLE `sls_web_setting` (
  `setting_id` int(11) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `invoice_logo` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `timezone` varchar(150) NOT NULL,
  `currency_position` varchar(10) DEFAULT NULL,
  `footer_text` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `rtr` varchar(255) DEFAULT NULL,
  `captcha` int(11) DEFAULT 1 COMMENT '0=active,1=inactive',
  `site_key` varchar(250) DEFAULT NULL,
  `secret_key` varchar(250) DEFAULT NULL,
  `discount_type` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sls_web_setting`
--

INSERT INTO `sls_web_setting` (`setting_id`, `logo`, `invoice_logo`, `favicon`, `currency`, `timezone`, `currency_position`, `footer_text`, `language`, `rtr`, `captcha`, `site_key`, `secret_key`, `discount_type`) VALUES
(1, 'assets/img/icons/2020-09-28/93feea3d8b9f1647dbd7be1eeda38ce7.png', 'assets/img/icons/2020-08-27/d57.png', 'assets/img/icons/2020-09-07/870.png', '$', 'Asia/Dhaka', '0', 'CopyrightÂ© 2020 Bdtask. All rights reserved.', 'english', '0', 1, '6LdiKhsUAAAAAMV4jQRmNYdZy2kXEuFe1HrdP5tt', '6LdiKhsUAAAAAMV4jQRmNYdZy2kXEuFe1HrdP5tt', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sls_customers`
--
ALTER TABLE `sls_customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`id`);

--
-- Indexes for table `sls_suppliers`
--
ALTER TABLE `sls_suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`id`);

--
-- Indexes for table `sls_users`
--
ALTER TABLE `sls_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sls_web_setting`
--
ALTER TABLE `sls_web_setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sls_customers`
--
ALTER TABLE `sls_customers`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sls_suppliers`
--
ALTER TABLE `sls_suppliers`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sls_users`
--
ALTER TABLE `sls_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `sls_web_setting`
--
ALTER TABLE `sls_web_setting`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
